<?php
date_default_timezone_set("Asia/Kathmandu");   //India time (GMT+5:30)

// Connection variables 
$host = "localhost"; // MySQL host name eg. localhost
$user = "id15575702_education"; // MySQL user. eg. root ( if your on localserver)
$password = "#@41Vijay#@41"; // MySQL user password  (if password is not set for your root user then keep it empty )
$database = "id15575702_project"; // MySQL Database name
$conn = mysqli_connect($host, $user, $password, $database);

?>
