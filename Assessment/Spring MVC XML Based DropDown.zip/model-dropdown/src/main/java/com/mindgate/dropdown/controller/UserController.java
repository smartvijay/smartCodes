package com.mindgate.dropdown.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mindgate.dropdown.model.User;

@Controller
public class UserController {
	
	@RequestMapping("/")
	public String showIndexPage() {
		return "index";
	}

   @RequestMapping(value = "/user", method = RequestMethod.GET)
   public ModelAndView user() {
      User user = new User();	  
//	  user.setFavoriteFrameworks((new String []{"Spring MVC","Struts 2"}));
//      user.setGender("M");
	  ModelAndView modelAndView = new ModelAndView("user", "command", user);
	  return modelAndView;
   }

   @RequestMapping(value = "/addUser", method = RequestMethod.POST)
   public String addUser(@ModelAttribute("SpringWeb")User user, 
      ModelMap model) {
//      model.addAttribute("username", user.getUsername());
//      model.addAttribute("password", user.getPassword());
//      model.addAttribute("address", user.getAddress());
//      model.addAttribute("receivePaper", user.isReceivePaper());
//	  model.addAttribute("favoriteFrameworks", user.getFavoriteFrameworks());
//      model.addAttribute("gender", user.getGender());
//      model.addAttribute("favoriteNumber", user.getFavoriteNumber());
      model.addAttribute("country", user.getCountry());     
      return "users";
   }
   
//   @ModelAttribute("webFrameworkList")
//   public List<String> getWebFrameworkList() {
//      List<String> webFrameworkList = new ArrayList<String>();
//      webFrameworkList.add("Spring MVC");
//      webFrameworkList.add("Struts 1");
//      webFrameworkList.add("Struts 2");
//      webFrameworkList.add("Apache Wicket");
//      return webFrameworkList;
//   }
//   
//   @ModelAttribute("numbersList")
//   public List<String> getNumbersList() {
//      List<String> numbersList = new ArrayList<String>();
//      numbersList.add("1");
//      numbersList.add("2");
//      numbersList.add("3");
//      numbersList.add("4");
//      return numbersList;
//   }

   @ModelAttribute("countryList")
   public Map<String, String> getCountryList() {
      Map<String, String> countryList = new HashMap<String, String>();
      countryList.put("US", "United States");
      countryList.put("CH", "China");
      countryList.put("SG", "Singapore");
      countryList.put("MY", "Malaysia");
      return countryList;
   }
}
   
//   xml based sample code
//   
//   studentform.jsp
//
//   <%@ taglib prefix = "form" uri = "http://www.springframework.org/tags/form" %>  
//    <html>
//    <head>
//    <title>Student Registration Form</title>
//    </head>
//    <body>
//    <form:form action = "studentregis" modelAttribute = "student" >
//    FIRST NAME: <form:input path = "fname" />
//    <br></br>
//    LAST NAME: <form:input path = "lname" />
//    <br></br>
//    <form:select path="country">
//       <form:option value = "IND" label = "India"></form:option>
//       <form:option value = "FRA" label = "France"></form:option>
//       <form:option value = "USA" label = "America"></form:option>
//       <form:option value = "DUB" label = "Dubai"></form:option>
//       <form:option value = "NEP" label = "Nepal"></form:option>
//       <form:option value = "BHU" label = "Bhutan"></form:option>
//    </form:select>
//    <br></br>
//    <input type = "submit" value = "Submit"/>
//    </form:form>
//    </body>
//    </html>
//
//   controller
//
//   package com.mindgate.student.controller;
//
//   import java.util.logging.Logger;
//
//   import org.springframework.beans.factory.annotation.Autowired;
//   import org.springframework.stereotype.Controller;
//   import org.springframework.ui.Model;
//   import org.springframework.web.bind.annotation.ModelAttribute;
//   import org.springframework.web.bind.annotation.RequestMapping;
//
//   import com.mindgate.student.model.Student;
//
//   @Controller
//   public class StudentController {
//   	
//   			public Logger logger=Logger.getLogger(StudentController.class.getName());
//   				
//   			@RequestMapping("/")
//   			public String showIndexPage() {
//   				logger.info("=========showIndexPage() called=============="); 
//   				return "index";
//   			}
//   			 		
//               @RequestMapping("/student_form")
//               public String showStudentForm( Model m) {
//                           Student student = new Student();
//                           m.addAttribute("student", student);
//                           return "studentform" ;
//               }
//               @RequestMapping("/studentregis")
//               public String showStudentData(@ModelAttribute("student") Student student) {
//               return "student-data" ;
//               }
//    } 