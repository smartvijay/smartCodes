package com.mindgate.assessment.model;

import java.util.Map;

public class Student {
	private Map<String,Course> map;
	public Student(Map<String, Course> map) {
		super();
		this.map = map;
	}
	public Map<String, Course> getMap() {
		return map;
	}

	public void setMap(Map<String, Course> map) {
		this.map = map;
	}
}
