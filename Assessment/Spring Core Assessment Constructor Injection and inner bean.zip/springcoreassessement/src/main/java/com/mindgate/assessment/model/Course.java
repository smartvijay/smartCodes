package com.mindgate.assessment.model;

import java.util.List;
import java.util.Map;

public class Course {
	private List<String> courseNames;
	private String trainerName;
	private Map<String,String> courseWithDuration;
	public Course(List<String> courseNames, String trainerName, Map<String, String> courseWithDuration) {
		super();
		this.courseNames = courseNames;
		this.trainerName = trainerName;
		this.courseWithDuration = courseWithDuration;
	}
	public List<String> getCourseNames() {
		return courseNames;
	}

	public void setCourseNames(List<String> courseNames) {
		this.courseNames = courseNames;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	public Map<String, String> getCourseWithDuration() {
		return courseWithDuration;
	}

	public void setCourseWithDuration(Map<String, String> courseWithDuration) {
		this.courseWithDuration = courseWithDuration;
	}
}
