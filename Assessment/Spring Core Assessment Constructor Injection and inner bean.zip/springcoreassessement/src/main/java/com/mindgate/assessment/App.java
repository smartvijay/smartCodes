package com.mindgate.assessment;

import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mindgate.assessment.model.Course;
import com.mindgate.assessment.model.Student;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("bean.xml");
		Student student=context.getBean(Student.class);
		Map<String,Course> map=student.getMap();
		
    }
}
