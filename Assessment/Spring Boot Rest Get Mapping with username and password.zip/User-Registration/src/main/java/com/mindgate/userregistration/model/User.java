package com.mindgate.userregistration.model;

import org.springframework.stereotype.Component;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
@Component
public class User {
	private int userId;
	private String firstName;
	private String lastName;
	private String userName;
	private String pass;
	private long mobile;
	private String emailId;	
}