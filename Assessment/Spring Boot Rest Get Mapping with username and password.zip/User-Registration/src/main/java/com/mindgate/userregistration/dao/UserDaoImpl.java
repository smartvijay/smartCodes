package com.mindgate.userregistration.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.userregistration.model.User;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Override
	public User addUser(User user) {
		int rowCount=jdbcTemplate.update("INSERT INTO USERS (userid,firstName,lastName,userName,pass,mobile,emailid) VALUES (?,?,?,?,?,?,?)", new Object[] {user.getUserId(),user.getFirstName(),user.getLastName(),user.getUserName(),user.getPass(),user.getMobile(),user.getEmailId()});
		if(rowCount!=0)
			return user;
		else
			return null;
	}
	@SuppressWarnings("deprecation")
	@Override
	public User validateUser(String userName, String password) {
		return jdbcTemplate.queryForObject("SELECT * FROM USERS WHERE USERNAME = ? AND PASS = ?",new Object[] {userName,password} , new UserRowMapper());	
	}
}
