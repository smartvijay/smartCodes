package com.mindgate.userregistration.service;

import com.mindgate.userregistration.model.User;

public interface UserService {
	public User addUser(User user);
	public User validateUser(String userName, String password);
}
