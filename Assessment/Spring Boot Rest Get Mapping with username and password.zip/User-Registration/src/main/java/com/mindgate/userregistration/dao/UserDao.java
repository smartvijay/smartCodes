package com.mindgate.userregistration.dao;

import com.mindgate.userregistration.model.User;

public interface UserDao {
	public User addUser(User user);
	public User validateUser(String userName, String password);
}
