package com.mindgate.userregistration.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.userregistration.dao.UserDaoImpl;
import com.mindgate.userregistration.model.User;
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDaoImpl dao;
	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return dao.addUser(user);
	}
	@Override
	public User validateUser(String userName, String password) {
		// TODO Auto-generated method stub
		return dao.validateUser(userName, password);
	}
}
