package com.mindgate.mtb.service;

import org.springframework.stereotype.Service;

import com.mindgate.mtb.model.Ticket;

@Service
public class TicketService {

	public double calculateTotalCost(Ticket ticket) {
		// TODO Auto-generated method stub
		String ct = ticket.getCircleType();
		int nots = ticket.getNoOfTickets();
		if(ct.equals("K"))
		{
			return (150*nots);
		}
		else if(ct.equals("Q"))
		{
			return (250*nots);
		}
		return 0;
	}
}
