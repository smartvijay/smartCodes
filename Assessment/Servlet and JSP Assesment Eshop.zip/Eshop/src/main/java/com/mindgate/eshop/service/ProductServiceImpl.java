package com.mindgate.eshop.service;

import java.util.List;

import com.mindgate.eshop.dao.ProductDaoImpl;
import com.mindgate.eshop.dto.Product;

public class ProductServiceImpl {
private ProductDaoImpl dao;
	
	public ProductServiceImpl() {
		System.out.println("Product Sevice Impl Class Called");
		dao=new ProductDaoImpl();
	}
	
	public void saveProduct(Product prd) {
		dao.saveProduct(prd);
	}

	public List<Product> getAllProduct() {
		return dao.getAllProduct();
	}

}