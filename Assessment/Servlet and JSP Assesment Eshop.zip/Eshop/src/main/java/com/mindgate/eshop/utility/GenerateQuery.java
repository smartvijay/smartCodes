package com.mindgate.eshop.utility;

import com.mindgate.eshop.dto.Product;

public class GenerateQuery {
	public static String generateInsertQuery(Product prd) {
		StringBuffer sb=new StringBuffer();
		sb.append("insert into product values(");
		sb.append(prd.getPrdid());
		sb.append(",");
		sb.append("'"+prd.getName()+"'");
		sb.append(",");
		sb.append(prd.getQuantity());
		sb.append(",");
		sb.append("'"+prd.getPrice()+"'");
		sb.append(")");
		System.out.println(sb.toString());
		return sb.toString();
	}
	
}