package com.mindgate.eshop.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mindgate.eshop.dto.Product;
import com.mindgate.eshop.service.ProductServiceImpl;

public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductServiceImpl  service=null;
    private Product  product;;

 public ProductServlet() {
     super(); 
     service=new ProductServiceImpl();
     product=new Product();
 }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Post Method : Success");
		
		product.setPrdid(Integer.parseInt(request.getParameter("prdid")));
		product.setName(request.getParameter("productname"));
		product.setQuantity(Integer.parseInt(request.getParameter("quantity")));
		product.setPrice(request.getParameter("price"));
		
		service.saveProduct(product);
		
		List<Product> listOfProduct=service.getAllProduct();
		
		HttpSession session=request.getSession();
		
		session.setAttribute("products", listOfProduct);
		RequestDispatcher rd=request.getRequestDispatcher("display-product.jsp");
		
		
		System.out.println("Display Product jsp file called");
		rd.forward(request, response);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		System.out.println("Get Method Filed : doGet");
	
		System.out.println("Error : Verify ProductServlet.java");
	}
}