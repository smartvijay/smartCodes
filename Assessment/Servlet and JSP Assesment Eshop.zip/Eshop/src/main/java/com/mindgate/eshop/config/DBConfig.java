package com.mindgate.eshop.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConfig {
				public static Statement createOracleStatementObject() {
					Statement statement=null;
					
					try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						System.out.println("JDBC Driver Loded");
						String dbUrl="jdbc:oracle:thin:@localhost:1521:xe";
						String dbUsername="SYSTEM";
						String dbPassword="12345";
						Connection con=DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
						statement=con.createStatement();
						System.out.println("Database Connected");
					} catch (ClassNotFoundException e) {
						e.printStackTrace();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					return statement;
				}
}
