package com.mindgate.eshop.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mindgate.eshop.config.DBConfig;
import com.mindgate.eshop.dto.Product;
import com.mindgate.eshop.utility.GenerateQuery;

public class ProductDaoImpl {

	private Statement statement;

	public ProductDaoImpl() {
		System.out.println("ProductDaoImpl class called");
		statement = DBConfig.createOracleStatementObject();
	}

	public void saveProduct(Product prd) {
		String insertQuery = GenerateQuery.generateInsertQuery(prd);
		try {
			int rowCount = statement.executeUpdate(insertQuery);

			if (rowCount > 0)
				System.out.println("Product Details Inserted Successfully");

			else
				System.out.println("Product Details Not Inserted");

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public List<Product> getAllProduct() {
		String retrieveAllProductQuery = "select * from product";
		ResultSet rs = null;
		List<Product> productList = new ArrayList<Product>();
		Product prd = null;
		try {
			rs = statement.executeQuery(retrieveAllProductQuery);
			while (rs.next()) {
				prd = new Product();
				prd.setPrdid(rs.getInt(1));
				prd.setName(rs.getString(2));
				prd.setQuantity(rs.getInt(3));
				prd.setPrice(rs.getString(4));
				productList.add(prd);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return productList;
	}

}