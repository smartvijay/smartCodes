package com.eshop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eshop.dto.Product;
import com.eshop.service.ProductService;

@RestController
@CrossOrigin("*")
@RequestMapping("/products")
public class ProductController
{
	
	@Autowired
	private ProductService service;
	@Autowired
	private Product product;
	@GetMapping("/{pid}")
	List<Product> getProductById(@PathVariable("pid")int pid)
	{
		return service.getProductById(pid);
	}
	@GetMapping()
	List<Product> getAllProduct()
	{
		return service.getAllProduct();
	}
	@PostMapping()
	Product saveProduct(@RequestBody Product product) {
		return service.saveProduct(product);
	}
	
	@PutMapping("/{pid}")
	Product updateProduct(@RequestBody Product product,@PathVariable("pid")int pid) {
		return service.updateProduct(product,pid);
	}
	@DeleteMapping("/{pid}")
	void deleteProduct(@PathVariable("pid")int pid) {
		service.deleteProduct(pid);
	}
}
