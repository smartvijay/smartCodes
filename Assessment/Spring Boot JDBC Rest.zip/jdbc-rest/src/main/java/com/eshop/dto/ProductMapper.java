package com.eshop.dto;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ProductMapper implements RowMapper<Product>{

	@Override
	public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Product product=new Product();
		product.setPid(rs.getInt("pid"));
		product.setProductName(rs.getString("productName"));
		product.setQuantity(rs.getInt("quantity"));
		product.setPrice(rs.getFloat("price"));
		return product;
	}
}
