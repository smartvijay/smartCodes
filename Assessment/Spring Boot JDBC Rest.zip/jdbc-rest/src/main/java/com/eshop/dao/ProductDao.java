package com.eshop.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.eshop.dto.Product;
import com.eshop.dto.ProductMapper;



@Repository
public class ProductDao
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	public List<Product> getAllProduct() {
		return jdbcTemplate.query("SELECT * FROM product", new BeanPropertyRowMapper<Product>(Product.class));
	}
	public List<Product> getProductById(int pid) {
		return jdbcTemplate.query("SELECT * FROM product WHERE pid=?", new BeanPropertyRowMapper<Product>(Product.class), pid);
	}
	public Product saveProduct(Product product) {
		String insertQuery="insert into product(pid,productname,quantity,price) values ('" + product.getPid()+"','"+product.getProductName()+"','"+product.getQuantity()+"','"+product.getPrice()+"')";
		jdbcTemplate.update(insertQuery);
		return null;
	}
	public Product updateProduct(Product product, int pid) {
		String updateQuery="update product set productname = '"+product.getProductName()+"', quantity = '"+product.getQuantity()+"', price ='"+product.getPrice()+"' where pid='"+ product.getPid()+"'";
		jdbcTemplate.update(updateQuery);
		return null;	
	}
	public int deleteProduct(int pid) {
		return jdbcTemplate.update("DELETE FROM product WHERE pid=?", pid);
	}
}
