package com.eshop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eshop.dao.ProductDao;
import com.eshop.dto.Product;

@Service
public class ProductService 
{
	@Autowired
	private ProductDao dao;
	
	public List<Product> getProductById(int id)
	{
		return dao.getProductById(id);
	}

	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		return dao.saveProduct(product);
	}

	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return dao.getAllProduct();
	}

	public Product updateProduct(Product product, int pid) {
		// TODO Auto-generated method stub
		return dao.updateProduct(product,pid);
	}

	public void deleteProduct(int pid) {
		// TODO Auto-generated method stub
		dao.deleteProduct(pid);
	}
}
