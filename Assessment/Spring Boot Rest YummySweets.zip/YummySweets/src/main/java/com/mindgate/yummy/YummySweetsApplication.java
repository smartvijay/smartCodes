package com.mindgate.yummy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YummySweetsApplication {

	public static void main(String[] args) {
		SpringApplication.run(YummySweetsApplication.class, args);
	}
}
