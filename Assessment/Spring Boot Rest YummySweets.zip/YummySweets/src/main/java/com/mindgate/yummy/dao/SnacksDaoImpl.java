package com.mindgate.yummy.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.mindgate.yummy.model.Snacks;
@Repository
public class SnacksDaoImpl implements SnacksDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Override
	public boolean registerSnacks(Snacks snacks) {
		int rowCount =  jdbcTemplate.update("INSERT INTO SNACKS (SNO,SNACKSNAME,QUANTITY,PRICE) VALUES (?,?,?,?)", new Object[] {snacks.getSno(),snacks.getSnacksName(),snacks.getQuantity(),snacks.getPrice()});
		// TODO Auto-generated method stub
		if(rowCount == 0) {
			return false;
		}
		else {
			return true;
		}
	}
	public List<Snacks> displayAllSnacks() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from snacks ", new SnacksExtracter());  
	}
	@SuppressWarnings("deprecation")
	@Override
	public List<Snacks> getSnacksById(int sno) {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from snacks where sno = ?", new Object[]{ sno }, new SnacksExtracter());

	}
	
	@SuppressWarnings("deprecation")
	@Override
	public List<Snacks> findQuantityAndPrice(int quantity, float price) {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from snacks where quantity = ? AND price = ?", new Object[]{ quantity,price }, new SnacksExtracter());
		}
}
				

