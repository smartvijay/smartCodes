package com.mindgate.yummy.service;

import java.util.List;

import com.mindgate.yummy.model.Snacks;

public interface SnacksService {
	public boolean registerSnacks(Snacks snacks);
	public List<Snacks> displayAllSnacks();
	public List<Snacks> getSnacksById(int sno);
	public List<Snacks> findQuantityAndPrice(int quantity, float price);
}
