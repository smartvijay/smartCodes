package com.example.yummy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YummySweetsApplicationTests {

	@Test
	void contextLoads() {
	}

}
