package com.registration.service;

import com.registration.model.User;

public interface UserService 
{
	public User validateUserDetails(String name, String password);
	public User registerUser(User user);
	
}
