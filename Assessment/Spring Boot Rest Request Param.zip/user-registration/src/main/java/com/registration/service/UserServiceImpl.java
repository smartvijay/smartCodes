package com.registration.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registration.dao.UserDaoImpl;
import com.registration.model.User;

@Service
public class UserServiceImpl implements UserService
{
	@Autowired
	private UserDaoImpl dao;
	
	public User validateUserDetails(String name, String password) 
	{
		System.out.println(name+","+password);
		return dao.validateUser(name,password);
	}

	public User registerUser(User user)
	{
		
		return dao.registerUser(user);
	}

}
