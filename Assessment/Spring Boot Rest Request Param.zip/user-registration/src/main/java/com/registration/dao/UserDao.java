package com.registration.dao;

import com.registration.model.User;

public interface UserDao
{
	public User validateUser(String name, String password);
}
