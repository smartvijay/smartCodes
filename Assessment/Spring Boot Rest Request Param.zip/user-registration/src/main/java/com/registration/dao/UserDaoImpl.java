package com.registration.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.registration.model.User;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class UserDaoImpl implements UserDao
{
	@Autowired
	private JdbcTemplate template;
	
	public User validateUser(String name, String password)
	{	
		return template.queryForObject("select * from register where userName=? and pass=?",new Object[] {name,password} ,new RowMapper<User>()
		{

			@Override
			public User mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				User user=new User();
				user.setUserId(rs.getInt("UserId"));
				user.setFirstName(rs.getString("firstName"));
				user.setLastName(rs.getString("lastName"));
				user.setUserName(rs.getString("userName"));
				user.setPassword(rs.getString("pass"));
				user.setMobileNumber(rs.getLong("mobileNumber"));
				user.setEmailId(rs.getString("emailId"));
				
				return user;
			}
		});
	}

	public User registerUser(User user) 
	{
	
		int rowsAffected=template.update("insert into register values(?,?,?,?,?,?,?)", new Object[] {user.getUserId(),user.getFirstName(),user.getLastName(),user.getUserName(),user.getPassword(),user.getMobileNumber(),user.getEmailId()});
		if(rowsAffected!=0)
		{
			return user;
		}
		return null;
	}	
}
