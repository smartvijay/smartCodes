package com.registration.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.registration.model.User;
import com.registration.service.UserServiceImpl;

@RestController
@RequestMapping("/reg")
public class UserController
{	
	@Autowired
	private UserServiceImpl service;
	
	@PostMapping
	public User validate(@RequestParam("userName")String name,@RequestParam("password") String password)
	{
		System.out.println(name+","+password);
		
		return service.validateUserDetails(name,password);	
		
	}
	
	@PostMapping("/")
	public User registerUser(@RequestBody User user)
	{
		return service.registerUser(user);	
	}
}	
