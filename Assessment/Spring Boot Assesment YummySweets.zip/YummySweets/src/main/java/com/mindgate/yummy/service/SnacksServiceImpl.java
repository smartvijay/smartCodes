package com.mindgate.yummy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.yummy.dao.SnacksDao;
import com.mindgate.yummy.dao.SnacksDaoImpl;
import com.mindgate.yummy.model.Snacks;
@Service
public class SnacksServiceImpl implements SnacksService {
	@Autowired
	private SnacksDao dao;
	@Autowired
	private SnacksDaoImpl daoi;

	public List<Snacks> displayAllSnacks(){
		return daoi.displayAllSnacks();
	}

	@Override
	public Boolean registerSnacks(Snacks snacks) {
		// TODO Auto-generated method stub
		return dao.registerSnacks(snacks);
	}
}
