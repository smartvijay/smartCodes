package com.mindgate.yummy.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.mindgate.yummy.model.Snacks;
@Repository
public class SnacksDaoImpl implements SnacksDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Override
	public Boolean registerSnacks(Snacks snacks) {
		// TODO Auto-generated method stub
		String insertQuery="insert into snacks(sno,snacksname,quantity,price) values ('" + snacks.getSno()+"','"+snacks.getSnacksName()+"','"+snacks.getQuantity()+"','"+snacks.getPrice()+"')";
		jdbcTemplate.update(insertQuery);
		return true;
	}
	public List<Snacks> displayAllSnacks() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from snacks ", new ResultSetExtractor<List<Snacks>>(){  
		    public List<Snacks> extractData(ResultSet rs) throws SQLException,  
		        DataAccessException {  
		        List<Snacks> list=new ArrayList<Snacks>();  
		        while(rs.next()){  
		        Snacks snacks=new Snacks();  
		        snacks.setSno(rs.getInt("sno"));
				snacks.setSnacksName(rs.getString("snacksName"));
				snacks.setQuantity(rs.getInt("quantity"));
				snacks.setPrice(rs.getFloat("price"));
		        list.add(snacks);  
		        }  
		        return list;  
		        }  
		    });  
	}
}
