package com.mindgate.yummy.service;

import java.util.List;

import com.mindgate.yummy.model.Snacks;

public interface SnacksService {
	public Boolean registerSnacks(Snacks snacks);
}
