package com.mindgate.yummy.config;

import javax.sql.DataSource;

import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
@SpringBootConfiguration
public class DatabaseConfig {
	@Bean
	public JdbcTemplate getJdbcTemplate(DataSource dataSource)
	{
		return new JdbcTemplate(dataSource);
	}	
}
