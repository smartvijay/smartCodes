package com.mindgate.yummy.model;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Snacks {
	private int sno;
	private String snacksName;
	private int quantity;
	private float price;
}
