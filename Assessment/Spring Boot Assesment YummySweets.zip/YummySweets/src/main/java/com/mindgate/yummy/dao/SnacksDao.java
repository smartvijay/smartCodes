package com.mindgate.yummy.dao;

import java.util.List;

import com.mindgate.yummy.model.Snacks;

public interface SnacksDao {
	public Boolean registerSnacks(Snacks snacks);
}
