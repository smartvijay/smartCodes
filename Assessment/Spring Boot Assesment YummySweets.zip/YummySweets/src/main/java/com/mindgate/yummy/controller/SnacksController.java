package com.mindgate.yummy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.yummy.model.Snacks;
import com.mindgate.yummy.service.SnacksService;
import com.mindgate.yummy.service.SnacksServiceImpl;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/snacks")
@Slf4j
public class SnacksController {
	@Autowired
	private Snacks snacks;
	@Autowired
	private SnacksService service;
	@Autowired
	private SnacksServiceImpl servicei;
	@GetMapping
	List<Snacks> displaySnacks()
	{
		log.info("Inside displaySnacks");
		return servicei.displayAllSnacks();
	}
	@PostMapping
	public Boolean addSnacks(@RequestBody Snacks snacks) {
		log.info("Inside addSnacks");
		return service.registerSnacks(snacks);
	}
}
