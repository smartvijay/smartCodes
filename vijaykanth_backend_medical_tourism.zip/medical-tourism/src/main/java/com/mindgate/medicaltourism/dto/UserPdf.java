package com.mindgate.medicaltourism.dto;

import java.sql.Blob;

public class UserPdf {
	private String pname;
	private Blob pdf;

	public Blob getPdf() {
		return pdf;
	}

	public void setPdf(Blob pdf) {
		this.pdf = pdf;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}
}
