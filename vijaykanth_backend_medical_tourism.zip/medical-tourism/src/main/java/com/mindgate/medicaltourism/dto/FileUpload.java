package com.mindgate.medicaltourism.dto;

public class FileUpload {

	private String pname;
	private Byte[] pdf;

	public Byte[] getPdf() {
		return pdf;
	}

	public void setPdf(Byte[] pdf) {

		this.pdf = pdf;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

}