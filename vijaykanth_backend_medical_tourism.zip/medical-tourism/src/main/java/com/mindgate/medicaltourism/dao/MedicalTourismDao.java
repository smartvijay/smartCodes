package com.mindgate.medicaltourism.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import com.mindgate.medicaltourism.dto.FileUpload;
import com.mindgate.medicaltourism.dto.MedicalTourism;
import com.mindgate.medicaltourism.dto.MedicalTourismLoginValidate;
import com.mindgate.medicaltourism.dto.PatientRegister;
import com.mindgate.medicaltourism.dto.UserPdf;

@Repository
public class MedicalTourismDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public MedicalTourism saveEnquiey(MedicalTourism enquiry) {
		String insertQuery = "insert into enquiry(patientname,patientage,email,fullname,phonenumber,comments,password) values ('"
				+ enquiry.getPatientName() + "','" + enquiry.getPatientAge() + "','" + enquiry.getEmail() + "','"
				+ enquiry.getFullName() + "','" + enquiry.getPhoneNumber() + "'," + "'" + enquiry.getComments() + "','"
				+ enquiry.getPassword() + "')";
		jdbcTemplate.update(insertQuery);
		return null;
	}

	public PatientRegister savePatientDetails(PatientRegister patient) {
		String insertQuery = "insert into patient(patientname,patientage,email,fullname,phonenumber,comments,password) values ('"
				+ patient.getPatientName() + "','" + patient.getPatientAge() + "','" + patient.getEmail() + "','"
				+ patient.getFullName() + "','" + patient.getPhoneNumber() + "'," + "'" + patient.getComments() + "','"
				+ patient.getPassword() + "')";
		jdbcTemplate.update(insertQuery);
		return null;
	}

	public MedicalTourism file(MedicalTourism file) {

		return null;
	}

	@SuppressWarnings("deprecation")
	public MedicalTourismLoginValidate getLoginDataByUsernamePassword(String username, String password) {
		return jdbcTemplate.queryForObject("SELECT rollid FROM log WHERE username=? and password=?",
				new Object[] { username, password }, new RowMapper<MedicalTourismLoginValidate>() {

					@Override
					public MedicalTourismLoginValidate mapRow(ResultSet rs, int rowNum) throws SQLException {
						MedicalTourismLoginValidate login = new MedicalTourismLoginValidate();
						login.setRollid(rs.getString("rollid"));
						return login;
					}
				});
	}

	@SuppressWarnings("deprecation")
	public UserPdf getPdfByname(String pname) {
		return jdbcTemplate.queryForObject("SELECT pname,pdf FROM pdf WHERE pname=?", new Object[] { pname },
				new RowMapper<UserPdf>() {

					@Override
					public UserPdf mapRow(ResultSet rs, int rowNum) throws SQLException {
						UserPdf upload = new UserPdf();
						upload.setPname(rs.getString("pname"));
						upload.setPdf(rs.getBlob("pdf"));
						return upload;
					}
				});
	}

	public FileUpload getUpload(byte[] pdf, String pname) {
		this.jdbcTemplate.update("insert into pdf(pdf, pname) values (?, ?)", new Object[] { pdf, pname });
		return null;

	}

	public List<MedicalTourism> getAllUsers() {
		return jdbcTemplate.query("SELECT * FROM register",
				new BeanPropertyRowMapper<MedicalTourism>(MedicalTourism.class));
	}

	public List<PatientRegister> getAllPatient() {
		return jdbcTemplate.query("SELECT * FROM patient",
				new BeanPropertyRowMapper<PatientRegister>(PatientRegister.class));
	}

	public List<FileUpload> getAllPdf() {
		return jdbcTemplate.query("SELECT * FROM pdf", new BeanPropertyRowMapper<FileUpload>(FileUpload.class));

	}

}
