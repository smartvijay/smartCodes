package com.mindgate.medicaltourism.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.mindgate.medicaltourism.dto.FileUpload;
import com.mindgate.medicaltourism.dto.MedicalTourism;
import com.mindgate.medicaltourism.dto.MedicalTourismLoginValidate;
import com.mindgate.medicaltourism.dto.PatientRegister;
import com.mindgate.medicaltourism.dto.UserPdf;
import com.mindgate.medicaltourism.service.MedicalTourismService;

@RestController
@CrossOrigin("*")
@RequestMapping("/medical")

public class MedicalTourismController {
	@Autowired
	private MedicalTourismService service;

	@GetMapping("/get")
	MedicalTourismLoginValidate getLoginDataByUsernamePassword(@RequestParam("username") String username,
			@RequestParam("password") String password) {
		System.out.println("Register method called");
		return service.getLoginDataByUsernamePassword(username, password);
	}

	@GetMapping("/getoneuser")
	UserPdf getPdfByname(@RequestParam("pname") String pname) {
		System.out.println("Register method called");
		return service.getPdfByname(pname);
	}

	@PostMapping(value = "/pdf", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public FileUpload upload(@RequestParam("file") MultipartFile file, @RequestParam("pname") String pname)
			throws IOException {

		byte[] byteArr = file.getBytes();

		byte[] encodedbytes = Base64.getEncoder().encode(byteArr);

		File filek = new File("E:/pdf/sample.pdf");

		try (FileOutputStream fos = new FileOutputStream(filek);) {
			byte[] decodedBytes = Base64.getDecoder().decode(encodedbytes);

			fos.write(decodedBytes);
			System.out.println("PDF File Saved");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return service.getUpload(encodedbytes, pname);
	}

	@GetMapping("/getpdf")
	List<FileUpload> getAllPdf() {

		return service.getAllPdf();
	}

	@PostMapping("/enquiry")
	MedicalTourism saveEnquiey(@RequestBody MedicalTourism enquiry) {
		System.out.println("Register method called");
		return service.saveEnquiey(enquiry);
	}

	@PostMapping("/patient")
	PatientRegister savePatientDetails(@RequestBody PatientRegister patient) {
		System.out.println("Register method called");
		return service.savePatientDetails(patient);
	}

	@GetMapping("/users")
	List<MedicalTourism> getAllUsers() {
		return service.getAllUsers();
	}

	@GetMapping("/getpatient")
	List<PatientRegister> getAllPatient() {
		return service.getAllPatient();
	}

	@GetMapping("/sendemail")
	public String sendEmail() throws AddressException, MessagingException, IOException {
		sendmail();
		return "Invite sent successfully";
	}

	private void sendmail() throws AddressException, MessagingException, IOException {
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("vijaykanthceg@gmail.com", "#@41Vijay");
			}
		});
		Message msg = new MimeMessage(session);
		msg.setFrom(new InternetAddress("vijaykanthceg@gmail.com", false));

		msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("vijayrrvvijay@gmail.com"));
		msg.setSubject("Medical Tourism Document for Visa");
		msg.setContent("Medical Tourism Document for Visa", "text/html");
		msg.setSentDate(new Date());

		MimeBodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setContent("Dear <User>  !\r\n" + "\r\n" + "Thanks for Choosing our Medical Tourism.\r\n"
				+ "\r\n" + "Please download the document below for visa purposes.\r\n" + "\r\n" + "Thank You \r\n"
				+ "\r\n" + "Incase any queries contact us : vijay@acmenol.in", "text/html");
		Multipart multipart = new MimeMultipart();
		multipart.addBodyPart(messageBodyPart);
		MimeBodyPart attachPart = new MimeBodyPart();

		attachPart.attachFile("E:\\docs pdf\\invite\\invitation_visitor_janani.pdf");
		multipart.addBodyPart(attachPart);
		msg.setContent(multipart);
		Transport.send(msg);
	}
}
