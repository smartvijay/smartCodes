package com.mindgate.medicaltourism.dto;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class MedicalTourismMapper implements RowMapper<MedicalTourism> {
	@Override
	public MedicalTourism mapRow(ResultSet rs, int rowNum) throws SQLException {
		MedicalTourism enquiry = new MedicalTourism();
		enquiry.setPatientName(rs.getString("patientName"));
		enquiry.setPatientAge(rs.getString("patientAge"));
		enquiry.setEmail(rs.getString("email"));
		enquiry.setFullName(rs.getString("fullName"));
		enquiry.setPhoneNumber(rs.getString("phoneNumber"));
		enquiry.setComments(rs.getString("comments"));
		enquiry.setPassword(rs.getString("password"));
		return enquiry;
	}
}
