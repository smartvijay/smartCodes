package com.mindgate.medicaltourism.dto;

public class MedicalTourismLoginValidate {
	private String rollid;

	public String getRollid() {
		return rollid;
	}

	public void setRollid(String rollid) {
		this.rollid = rollid;
	}

}
