package com.mindgate.medicaltourism.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindgate.medicaltourism.dao.MedicalTourismDao;
import com.mindgate.medicaltourism.dto.FileUpload;
import com.mindgate.medicaltourism.dto.MedicalTourism;
import com.mindgate.medicaltourism.dto.MedicalTourismLoginValidate;
import com.mindgate.medicaltourism.dto.PatientRegister;
import com.mindgate.medicaltourism.dto.UserPdf;

@Service
public class MedicalTourismService {
	@Autowired
	private MedicalTourismDao dao;

	public MedicalTourism saveEnquiey(MedicalTourism enquiry) {
		return dao.saveEnquiey(enquiry);
	}

	public PatientRegister savePatientDetails(PatientRegister patient) {
		return dao.savePatientDetails(patient);
	}

	public MedicalTourismLoginValidate getLoginDataByUsernamePassword(String username, String password) {
		return dao.getLoginDataByUsernamePassword(username, password);
	}

	public UserPdf getPdfByname(String pname) {
		return dao.getPdfByname(pname);
	}

	public List<MedicalTourism> getAllUsers() {

		return dao.getAllUsers();
	}

	public List<PatientRegister> getAllPatient() {

		return dao.getAllPatient();
	}

	public List<FileUpload> getAllPdf() {

		return dao.getAllPdf();
	}

	public FileUpload getUpload(byte[] pdf, String pname) {

		return dao.getUpload(pdf, pname);
	}

}
