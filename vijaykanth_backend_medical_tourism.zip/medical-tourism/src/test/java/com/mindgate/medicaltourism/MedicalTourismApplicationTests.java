package com.mindgate.medicaltourism;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalTourismApplicationTests {

	@Test
	void contextLoads() {
	}

}
