load_process_KIBA
========================================================================================================







**load_process_KIBA** load KIBA dataset. 


.. code-block:: python


	load_process_KIBA(path = './data', binary = False, threshold = 9):

* **path** (str, a directory) - the path that save KIBA dataset file. Example: "./data". 
* **binary** (bool) - If binary is True, formulate prediction task as a binary classification task. Otherwise, formulate the prediction task as a regression task. 
* **threshold** (float) - The threshold that select target score ?? 









