load_AID1706_txt_file
========================================================================================================



**load_AID1706_txt_file** load KIBA dataset. 

.. code-block:: python


  load_AID1706_txt_file(path = './data')

* **path** (str, a directory) - the path that save AID1706 dataset file. Example: "./data". 





