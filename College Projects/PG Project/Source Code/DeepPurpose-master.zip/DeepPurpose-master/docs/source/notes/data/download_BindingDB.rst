download_DrugTargetCommons
========================================================================================================





**download_DrugTargetCommons** load DrugTargetCommons dataset, save it to a specific path. 
If the path doesn't exist, create the folder. 

.. code-block:: python

	dataset.download_DrugTargetCommons(path)

* **path** (str, a directory) - the path that save DrugTargetCommons dataset file. Example: "./data". 







