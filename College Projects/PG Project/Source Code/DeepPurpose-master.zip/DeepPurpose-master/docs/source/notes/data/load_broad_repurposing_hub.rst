load_broad_repurposing_hub
========================================================================================================





**load_broad_repurposing_hub** load repurposing dataset. 

.. code-block:: python

	load_broad_repurposing_hub(path = './data'):

* **path** (str, a directory) - the path that save repurposing dataset file. Example: "./data". 







