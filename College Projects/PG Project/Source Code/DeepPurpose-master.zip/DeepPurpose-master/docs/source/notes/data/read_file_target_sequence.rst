read_file_target_sequence
========================================================================================================



**read_file_target_sequence** load drug repurposing dataset. 
We have requirement on format of file.
The file only have one line. 
The line contains target name and target sequence. 
Example: ./toy_data/??

.. code-block:: python

	dataset.read_file_target_sequence(path)

* **path** (str, a directory) - the path of target sequence dataset file. 




