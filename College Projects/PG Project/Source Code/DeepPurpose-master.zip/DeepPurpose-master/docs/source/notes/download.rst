Download Code & Install
========================================================================


Download Code
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


.. code-block:: bash

   $ git clone https://github.com/kexinhuang12345/DeepPurpose.git
   $ ###  Download code repository 
   $
   $
   $ cd DeepPurpose
   $ ### Change directory to DeepPurpose 


First time usage: setup conda environment
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: bash

   $ conda env create -f environment.yml  
   $ ## Build virtual environment with all packages installed using conda
   $ 
   $ conda activate DeepPurpose
   $ ##  Activate conda environment
   $
   $
   $ conda deactivate ### exit



Second time and later
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: bash

   $ conda activate DeepPurpose
   $ ##  Activate conda environment
   $
   $
   $ conda deactivate ### exit



