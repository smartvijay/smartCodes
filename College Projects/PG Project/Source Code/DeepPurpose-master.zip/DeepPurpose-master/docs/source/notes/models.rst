DeepPurpose.models
================================================

.. toctree::
   :glob:
   :maxdepth: 1
   :caption: Documentation of function in DeepPurpose.models

   dtba/classifier
   dtba/dbta
   encoders/transformer
   encoders/mpnn
   encoders/cnnrnn
   encoders/cnn 
   encoders/mlp 



