Utility Function
========================





